const app = getApp()
// canvas 全局配置
var context = null;
var isButtonDown = false;
var arrx = [];
var arry = [];
var arrz = [];
var canvasw = 0;
var canvash = 0;
//注册页面
Page({
  canvasIdErrorCallback: function (e) {
    console.error(e.detail.errMsg)
  },
  //开始
  canvasStart: function (event) {
    isButtonDown = true;
    arrz.push(0);
    arrx.push(event.changedTouches[0].x);
    arry.push(event.changedTouches[0].y);

  },
  data: {
    src: "",
    img: "https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=578899140,1412678472&fm=27&gp=0.jpg",
    rpx: '',
    id:"",
    width1:0,
    height1: 0,
    width2 :0,
    height2 : 0
  },

  onLoad: function (options) {
    var that = this
    this.setData({
      id: options.id
    });
    that.data.canvasw= wx.getSystemInfoSync().windowWidth
    that.data.canvash=wx.getSystemInfoSync().windowHeight
    // 使用 wx.createContext 获取绘图上下文 context
    context = wx.createCanvasContext('canvas');
    context.beginPath()
    this.cleardraw()
    /**新加的 */
    context.setFillStyle('#ffffff');
    context.fillRect(0, 0, 1000, 1800);
    context.draw(true);
     /**。新加的 */
    context.setStrokeStyle('#000000');
    context.setLineWidth(4);
    context.setLineCap('round');
    context.setLineJoin('round');
    // context.drawImage('../../images/img111.png', 0, 0, canvasw, 500);
    context.draw(true);
    console.log(canvasw)
    /**新加节点选择器 */
    //创建节点选择器
    var query = wx.createSelectorQuery();
    query.select('#canvas').boundingClientRect(function (rect) {
      that.data.width1 = parseInt(rect.width) * 6
      that.data.height1 = parseInt(rect.height) * 6
      that.data.width2 = rect.width
      that.data.height2 = rect.height
      console.log(that.data.width1)
    }).exec();
    /**新加节点选择器 */
  },

  //过程
  canvasMove: function (event) {
    var that = this
    if (isButtonDown) {
      arrz.push(1);
      console.log(event)
      arrx.push(event.changedTouches[0].x);
      arry.push(event.changedTouches[0].y);
    };

    for (var i = 0; i < arrx.length; i++) {
      if (arrz[i] == 0) {
        context.moveTo(arrx[i], arry[i])
      } else {
        context.lineTo(arrx[i], arry[i])
      };

    };
    context.clearRect(0, 0, canvasw, canvash);
    context.setStrokeStyle('#000000');
    context.setLineWidth(4);
    context.setLineCap('round');
    context.setLineJoin('round');
    context.stroke();
    context.draw(true);
  },
  // 点击保存图片
  clickMe: function () {
    var that = this
    wx.hideLoading()
    wx.canvasToTempFilePath({
      width: that.data.width2,
      height: that.data.height2,
      destWidth: that.data.width1,  //生成图片的大小设置成canvas大小的四倍
      destHeight: that.data.height1,
      quality: 1,//图片质量,
      canvasId: 'canvas',
      fileType: 'jpg',
      success: function (res) {
        console.log(res)
        var signPic = app.globalData.signArray 
        var id=that.data.id
        for (var z in signPic) {
          if (id == z) {
            // debugger
            // var newtempFilePath = wx.env.USER_DATA_PATH +'/'+ res.tempFilePath
            // let base64 = wx.getFileSystemManager().readFileSync(newtempFilePath, 'base64')
            // console.log(base64)
            let base64 = wx.getFileSystemManager().readFileSync(res.tempFilePath, 'base64') 
            signPic[id] = base64
            app.globalData.signArray = signPic;
            wx.navigateBack({
                  url: '../table/table'
                })
          }
        }
      }
    })

    // this.cleardraw()//新加的清除画布
  },
  canvasEnd: function (event) {
    isButtonDown = false;
  },
  cleardraw: function () {
    //清除画布
    arrx = [];
    arry = [];
    arrz = [];
    context.draw(false);
  }

})